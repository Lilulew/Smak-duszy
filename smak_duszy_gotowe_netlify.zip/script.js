
// script.js – dodatkowe interakcje
console.log("Witamy w Smaku Duszy!");
